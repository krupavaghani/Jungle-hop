import 'dart:async';

import 'package:flutter/material.dart';
import 'package:jungle_jumpping/widgets/top_header.dart';

import '../services/coin_history_service.dart';
import '../services/premium_service.dart';
import '../services/remove_ads_purchase_service.dart';
import '../utils/colors.dart';

class _CoinPackage {
  final int coins;
  final String price;
  final String imageAsset;
  final bool isBestValue;

  const _CoinPackage({
    required this.coins,
    required this.price,
    required this.imageAsset,
    this.isBestValue = false,
  });
}

class CoinStoreScreen extends StatefulWidget {
  const CoinStoreScreen({super.key});

  @override
  State<CoinStoreScreen> createState() => _CoinStoreScreenState();
}

class _CoinStoreScreenState extends State<CoinStoreScreen> {
  static const List<_CoinPackage> _packages = [
    _CoinPackage(
      coins: 100,
      price: '\$0.99',
      imageAsset: 'assets/images/100Coin.png',
    ),
    _CoinPackage(
      coins: 250,
      price: '\$1.99',
      imageAsset: 'assets/images/250Coin.png',
    ),
    _CoinPackage(
      coins: 500,
      price: '\$2.99',
      imageAsset: 'assets/images/500Coin.png',
    ),
    _CoinPackage(
      coins: 1000,
      price: '\$4.99',
      imageAsset: 'assets/images/1000Coin.png',
      isBestValue: true,
    ),
    _CoinPackage(
      coins: 2500,
      price: '\$9.99',
      imageAsset: 'assets/images/2500Coin.png',
    ),
    _CoinPackage(
      coins: 5000,
      price: '\$19.99',
      imageAsset: 'assets/images/5000Coin.png',
    ),
  ];

  final RemoveAdsPurchaseService _removeAds = RemoveAdsPurchaseService.instance;
  StreamSubscription<void>? _purchaseSettledSub;

  int _availableCoins = 0;
  bool _isPurchasingRemoveAds = false;

  bool get _isPremium => PremiumService.instance.isPremiumUser;

  @override
  void initState() {
    super.initState();
    PremiumService.instance.addListener(_onPremiumChanged);
    _purchaseSettledSub = _removeAds.purchaseSettled.listen((_) {
      if (!mounted) return;
      if (!PremiumService.instance.isPremiumUser) {
        setState(() => _isPurchasingRemoveAds = false);
      }
    });
    _loadCoins();
  }

  @override
  void dispose() {
    _purchaseSettledSub?.cancel();
    PremiumService.instance.removeListener(_onPremiumChanged);
    super.dispose();
  }

  void _onPremiumChanged() {
    if (!mounted) return;
    setState(() {
      _isPurchasingRemoveAds = false;
    });
    if (PremiumService.instance.isPremiumUser) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Ads removed. Enjoy uninterrupted play!'),
        ),
      );
    }
  }

  Future<void> _loadCoins() async {
    final coins = await CoinHistoryService.getAvailableCoins();
    if (!mounted) return;
    setState(() => _availableCoins = coins);
  }

  Future<void> _purchaseRemoveAds() async {
    if (_isPremium || _isPurchasingRemoveAds) return;

    setState(() => _isPurchasingRemoveAds = true);

    if (!_removeAds.storeAvailable) {
      if (!mounted) return;
      setState(() => _isPurchasingRemoveAds = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Store is not available. Try again later.'),
        ),
      );
      return;
    }

    final started = await _removeAds.buyRemoveAds();
    if (!mounted) return;

    if (!started && !_isPremium) {
      setState(() => _isPurchasingRemoveAds = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not start purchase.')),
      );
    } else if (_isPremium) {
      setState(() => _isPurchasingRemoveAds = false);
    }
    // Success is handled via purchase stream → PremiumService listener.
  }

  String get _removeAdsPrice {
    return _removeAds.localizedPrice ?? '\$2.99';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/shopBg.png'),
            fit: BoxFit.cover,
          ),
        ),
        child: LayoutBuilder(
          builder: (context, constraints) {
            final scale = (constraints.maxWidth / 375).clamp(0.85, 1.15);
            final horizontalPad = (16 * scale).clamp(12.0, 20.0);

            return Padding(
              padding: EdgeInsets.symmetric(horizontal: horizontalPad),
              child: Column(
                children: [
                  TopHeader(label: 'COIN SHOP'),
                  SizedBox(height: (10 * scale).clamp(6.0, 14.0)),
                  _buildBanner(scale),
                  Align(
                    alignment: Alignment.centerRight,
                    child: _buildCoinBadge(scale),
                  ),
                  SizedBox(height: (14 * scale).clamp(10.0, 18.0)),
                  _buildSectionTitle(scale),
                  SizedBox(height: (10 * scale).clamp(6.0, 12.0)),
                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          GridView.builder(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemCount: _packages.length,
                            gridDelegate:
                                SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 3,
                              mainAxisSpacing: (10 * scale).clamp(8.0, 12.0),
                              crossAxisSpacing: (10 * scale).clamp(8.0, 12.0),
                              childAspectRatio: 0.62,
                            ),
                            itemBuilder: (context, index) {
                              return _CoinPackageCard(
                                package: _packages[index],
                                scale: scale,
                                onPurchase: () {},
                              );
                            },
                          ),
                          SizedBox(height: (10 * scale).clamp(4.0, 10.0)),
                          _buildRemoveAdsCard(scale),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildBanner(double scale) {
    return Stack(
      alignment: Alignment.centerRight,
      children: [
        Image.asset(
          'assets/images/get-coin-board.png',
          width: double.infinity,
          fit: BoxFit.contain,
        ),
        Padding(
          padding: EdgeInsets.only(
            right: (18 * scale).clamp(12.0, 24.0),
            left: (120 * scale).clamp(96.0, 140.0),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Get Coins',
                style: TextStyle(
                  fontFamily: 'FredokaOne',
                  fontSize: (24 * scale).clamp(18.0, 28.0),
                  color: Colors.white,
                  height: 1.05,
                  shadows: const [
                    Shadow(
                      color: Colors.black54,
                      blurRadius: 6,
                      offset: Offset(0, 1),
                    ),
                  ],
                ),
              ),
              SizedBox(height: (4 * scale).clamp(2.0, 6.0)),
              Text(
                'Unlock fun and exciting rewards!',
                style: TextStyle(
                  fontFamily: 'Nunito',
                  fontWeight: FontWeight.w800,
                  fontSize: (12 * scale).clamp(10.0, 14.0),
                  color: JColors.yellow,
                  height: 1.2,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildCoinBadge(double scale) {
    final padH = (10 * scale).clamp(8.0, 14.0);
    final padV = (6 * scale).clamp(4.0, 10.0);
    final font = (14 * scale).clamp(11.0, 16.0);
    final plus = (20 * scale).clamp(18.0, 24.0);
    final iconPlus = (14 * scale).clamp(12.0, 16.0);

    return Container(
      padding: EdgeInsets.symmetric(horizontal: padH, vertical: padV),
      decoration: BoxDecoration(
        color: const Color(0xFF0F0F12).withOpacity(0.85),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Image.asset('assets/images/coin.png', height: 25, fit: BoxFit.contain),
          SizedBox(width: (6 * scale).clamp(4.0, 8.0)),
          Text(
            '$_availableCoins',
            style: TextStyle(
              fontFamily: 'FredokaOne',
              fontSize: font,
              color: Colors.white,
            ),
          ),
          SizedBox(width: (8 * scale).clamp(6.0, 12.0)),
          GestureDetector(
            onTap: _loadCoins,
            child: Container(
              width: plus,
              height: plus,
              decoration: const BoxDecoration(
                color: JColors.brightGreen,
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.add,
                size: iconPlus,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRemoveAdsCard(double scale) {
    final radius = (16 * scale).clamp(12.0, 20.0);
    final imageHeight = (72 * scale).clamp(56.0, 84.0);
    final titleSize = (16 * scale).clamp(14.0, 18.0);
    final subtitleSize = (11 * scale).clamp(10.0, 12.0);
    final priceSize = (12 * scale).clamp(10.0, 14.0);
    final statusSize = (11 * scale).clamp(10.0, 12.0);

    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: (12 * scale).clamp(10.0, 16.0),
        vertical: (6 * scale).clamp(8.0, 12.0),
      ),
      decoration: BoxDecoration(
        color: const Color(0xFF1A3A14).withOpacity(0.82),
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: JColors.lightGreen.withOpacity(0.45)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.18),
            blurRadius: (8 * scale).clamp(6.0, 10.0),
            offset: Offset(0, (4 * scale).clamp(2.0, 6.0)),
          ),
        ],
      ),
      child: Row(
        children: [
          Image.asset(
            'assets/images/remove-ads.png',
            height: imageHeight,
            fit: BoxFit.contain,
          ),
          SizedBox(width: (10 * scale).clamp(8.0, 12.0)),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Remove Ads',
                  style: TextStyle(
                    fontFamily: 'FredokaOne',
                    fontSize: titleSize,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: (4 * scale).clamp(2.0, 6.0)),
                Text(
                  _isPremium
                      ? 'Ads are off across the jungle.'
                      : 'Enjoy uninterrupted jungle hops.',
                  style: TextStyle(
                    fontFamily: 'Nunito',
                    fontWeight: FontWeight.w700,
                    fontSize: subtitleSize,
                    color: Colors.white.withOpacity(0.78),
                    height: 1.2,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(width: (8 * scale).clamp(6.0, 10.0)),
          if (_isPremium)
            Container(
              padding: EdgeInsets.symmetric(
                horizontal: (10 * scale).clamp(8.0, 12.0),
                vertical: (6 * scale).clamp(4.0, 8.0),
              ),
              decoration: BoxDecoration(
                color: JColors.lightGreen.withOpacity(0.22),
                borderRadius: BorderRadius.circular((12 * scale).clamp(10.0, 14.0)),
                border: Border.all(color: JColors.lightGreen.withOpacity(0.55)),
              ),
              child: Text(
                'ACTIVE',
                style: TextStyle(
                  fontFamily: 'FredokaOne',
                  fontSize: statusSize,
                  color: JColors.lightGreen,
                ),
              ),
            )
          else if (_isPurchasingRemoveAds)
            Padding(
              padding: EdgeInsets.all((8 * scale).clamp(6.0, 10.0)),
              child: SizedBox(
                width: (24 * scale).clamp(20.0, 28.0),
                height: (24 * scale).clamp(20.0, 28.0),
                child: const CircularProgressIndicator(strokeWidth: 2),
              ),
            )
          else
            Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: _purchaseRemoveAds,
                borderRadius: BorderRadius.circular((12 * scale).clamp(10.0, 14.0)),
                child: Ink(
                  padding: EdgeInsets.symmetric(
                    horizontal: (12 * scale).clamp(10.0, 14.0),
                    vertical: (8 * scale).clamp(6.0, 10.0),
                  ),
                  decoration: BoxDecoration(
                    gradient: JColors.playButtonGradient,
                    borderRadius: BorderRadius.circular((12 * scale).clamp(10.0, 14.0)),
                  ),
                  child: Text(
                    _removeAdsPrice,
                    style: TextStyle(
                      fontFamily: 'FredokaOne',
                      fontSize: priceSize,
                      color: const Color(0xFF1A2A10),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(double scale) {
    final font = (18 * scale).clamp(15.0, 20.0);
    final leaf = (16 * scale).clamp(13.0, 18.0);
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text('🌿', style: TextStyle(fontSize: leaf)),
        SizedBox(width: (8 * scale).clamp(6.0, 10.0)),
        Text(
          'Coin Packages',
          style: TextStyle(
            fontFamily: 'FredokaOne',
            fontSize: font,
            color: JColors.trunk,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(width: (8 * scale).clamp(6.0, 10.0)),
        Text('🌿', style: TextStyle(fontSize: leaf)),
      ],
    );
  }
}

class _CoinPackageCard extends StatelessWidget {
  final _CoinPackage package;
  final double scale;
  final VoidCallback onPurchase;

  const _CoinPackageCard({
    required this.package,
    required this.scale,
    required this.onPurchase,
  });

  @override
  Widget build(BuildContext context) {
    final amountSize = (16 * scale).clamp(13.0, 18.0);
    final priceSize = (12 * scale).clamp(10.0, 14.0);
    final tagSize = (8 * scale).clamp(7.0, 10.0);
    final radius = (14 * scale).clamp(12.0, 16.0);

    return Container(
      padding: EdgeInsets.all((8 * scale).clamp(6.0, 10.0)),
      decoration: BoxDecoration(
        color: const Color(0xFF1A3A14).withOpacity(0.82),
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: JColors.lightGreen.withOpacity(0.45)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.18),
            blurRadius: (8 * scale).clamp(6.0, 10.0),
            offset: Offset(0, (4 * scale).clamp(2.0, 6.0)),
          ),
        ],
      ),
      child: Column(
        children: [
          if (package.isBestValue)
            Container(
              padding: EdgeInsets.symmetric(
                horizontal: (8 * scale).clamp(6.0, 10.0),
                vertical: (3 * scale).clamp(2.0, 4.0),
              ),
              decoration: BoxDecoration(
                gradient: JColors.playButtonGradient,
                borderRadius: BorderRadius.circular((10 * scale).clamp(8.0, 12.0)),
              ),
              child: Text(
                'BEST VALUE',
                style: TextStyle(
                  fontFamily: 'FredokaOne',
                  fontSize: tagSize,
                  color: const Color(0xFF1A2A10),
                  letterSpacing: 0.4,
                ),
              ),
            ),
          if (package.isBestValue)
            SizedBox(height: (4 * scale).clamp(2.0, 6.0)),
          Text(
            '${package.coins}',
            style: TextStyle(
              fontFamily: 'FredokaOne',
              fontSize: amountSize,
              color: Colors.white,
            ),
          ),
          SizedBox(height: (4 * scale).clamp(2.0, 6.0)),
          Expanded(
            child: Image.asset(
              package.imageAsset,
              fit: BoxFit.contain,
            ),
          ),
          SizedBox(height: (4 * scale).clamp(4.0, 6.0)),
          SizedBox(
            width: double.infinity,
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: onPurchase,
                borderRadius: BorderRadius.circular((12 * scale).clamp(10.0, 14.0)),
                child: Ink(
                  padding: EdgeInsets.symmetric(
                    vertical: (6 * scale).clamp(4.0, 8.0),
                  ),
                  decoration: BoxDecoration(
                    gradient: JColors.playButtonGradient,
                    borderRadius: BorderRadius.circular((12 * scale).clamp(10.0, 14.0)),
                  ),
                  child: Center(
                    child: Text(
                      package.price,
                      style: TextStyle(
                        fontFamily: 'FredokaOne',
                        fontSize: priceSize,
                        color: const Color(0xFF1A2A10),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
